```markdown
# Deployment Guide — Program Dashboard

This guide walks you through deploying the two pieces of the app:
- Server (Express + Supabase) — deploy to Railway or Render
- Frontend (React) — deploy to Vercel

It also covers Supabase setup, RLS policies, GitHub Actions scheduling for notifications, and local testing.

---

## A. Supabase setup (one-time)

1. Create project at https://supabase.com and note:
   - SUPABASE_URL (project URL) : "https://lkesgynwbxyhwprdbjin.supabase.co"
   - SERVICE_ROLE_KEY (server-only secret) :
   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxrZXNneW53Ynh5aHdwcmRiamluIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MDkyODY0NiwiZXhwIjoyMDc2NTA0NjQ2fQ.prlikS_8GCiIqTbWqu4_K7dT1xtTAsqv8QuGPIZQ1QA"
   - ANON KEY (frontend)
   - ANON Public:
   "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxrZXNneW53Ynh5aHdwcmRiamluIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA5Mjg2NDYsImV4cCI6MjA3NjUwNDY0Nn0.hnbxwEM3E1ilXjl9wkesj1aWJiHk-8KTK1zMUbfRGns"

2. Create the `programs` table:
   - Open Supabase > SQL Editor
   - Run the contents of `server/db.sql`:
     - Creates the programs table and index.

3. Add per-user ownership and RLS:
   - In the SQL editor run `server/db_rls.sql` (adds owner_id and RLS policies).
   - Confirm policies exist in Supabase UI: Auth → Policies.

4. Optional: enable "Email confirmations" or leave default.

---

## B. Server deployment (Railway or Render)

Common preparation:
- Ensure `server/index.js`, `server/package.json`, and `server/db.sql` / `server/db_rls.sql` are in the repo.
- Add the environment variables from `server/.env.example` into the platform secrets.

Railway (recommended for simplicity):
1. Sign up / log in to Railway (https://railway.app).
2. Create a new project → "Deploy from GitHub".
3. Select your repo and the `server` folder (if your server is in a subfolder).
4. In Railway > Project > Variables, add:
   - SUPABASE_URL
   - SUPABASE_SERVICE_ROLE_KEY
   - SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS
   - EMAIL_FROM, NOTIFY_TO_EMAIL, NOTIFY_API_KEY, NOTIFY_DAYS_BEFORE_END
5. Deploy. Railway will run `npm install` and `npm start`. Note the generated URL (e.g. https://program-server.up.railway.app).

Render:
1. Sign up at https://render.com.
2. New → Web Service → Connect repo.
3. Set Root Directory to `/server` (if needed), build command `npm install`, start `npm start`.
4. Add environment variables in the Render dashboard (same keys above).
5. Deploy and note the service URL.

Verify server:
- curl GET /api/programs with Authorization (for tests use no auth => 401 — that's expected if RLS enforced)
- Visit `https://your-server-domain/api/health` if you added a health route (optional).

---

## C. Frontend deployment (Vercel)

1. Sign up at https://vercel.com and connect your GitHub repo.
2. In Vercel, create a new project → import repo.
3. Configure Environment Variables (Settings → Environment Variables):
   - REACT_APP_SUPABASE_URL = your Supabase URL
   - REACT_APP_SUPABASE_ANON_KEY = your ANON KEY
   - REACT_APP_API_BASE_URL = https://your-server-domain
4. Build settings:
   - Framework: Create React App (auto-detected)
   - Build command: `npm run build`
   - Output dir: `build`
5. Deploy. Note the Vercel app URL.

Local dev:
- Server: cd server && cp .env.example .env && fill values && npm install && npm start
- Frontend: cp .env.local.example .env.local && fill values && npm install && npm start

---

## D. GitHub Actions scheduling (daily notify)

1. In your repo, add the workflow file `.github/workflows/daily_notify.yml` (provided above).
2. Add GitHub secrets (Repository Settings → Secrets → Actions):
   - NOTIFY_URL = https://your-server-domain/api/notify
   - NOTIFY_API_KEY = the same key you configured on the server
3. Manually trigger the workflow from the Actions tab to test or wait for schedule.

---

## E. Test flows & validation

1. Frontend:
   - Open the frontend URL.
   - Sign up / sign in.
   - Create a program and verify it appears in the table.
2. Supabase:
   - Open Supabase > Table Editor > programs
   - Confirm new program has owner_id = your user id.
3. CSV import/export:
   - Import a CSV with headers `Type Program,Brand,Pencapaian` from frontend; confirm rows created.
   - Use Export to download CSV via server endpoint.
4. Notify:
   - Manually run the GitHub Action or call:
     ```
     curl -X POST https://your-server-domain/api/notify -H "x-notify-api-key: YOUR_KEY"
     ```
   - Check the recipient inbox (NOTIFY_TO_EMAIL).

---

## F. Troubleshooting

- 401 Unauthorized on API calls:
  - Ensure frontend is sending Authorization header. After signing in, the AuthContext sets the token and api.setAuthToken is called.
  - Check server logs to see whether supabase.auth.getUser(token) returned an error.
- Emails not sending:
  - Verify SMTP credentials and that SMTP_PORT/SECURE are correct.
  - Check server logs for nodemailer errors.
- RLS blocking access in Supabase Console:
  - For server side queries using SERVICE_ROLE_KEY you can ignore RLS; but client JWT requests must respect RLS — confirm policies created in `server/db_rls.sql`.
- Missing DB schema:
  - Re-run `server/db.sql` in Supabase SQL editor.

---

## G. Extra tips

- For low-cost SMTP testing, use a Gmail account with an app password, or use Mailgun/Sendinblue free tiers.
- For GitHub Actions secrets, prefer organization or repo-level secrets and rotate them periodically.
- If you want serverless deployment (Vercel functions), I can convert the Express endpoints into Next.js API routes.

```