import React, { useEffect } from "react";
import { AuthProvider, useAuth } from "./AuthContext";
import api from "./api";
import MainApp from "./MainApp";
import MyAccount from "./components/MyAccount";

/**
 * App.js
 *
 * Top-level wrapper: provides AuthProvider and places MyAccount in the header.
 * When the auth token changes, it sets api.setAuthToken(...) so API calls include the user's JWT.
 *
 * Usage: keep this as the app entry component mounted in index.js
 */

function InnerApp() {
  const { accessToken } = useAuth();

  useEffect(() => {
    api.setAuthToken(accessToken);
  }, [accessToken]);

  // optional navigation handler for MyAccount dropdown
  function handleNavigate(route) {
    if (route === "programs") {
      window.location.hash = "#programs";
    } else if (route === "settings") {
      window.location.hash = "#settings";
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald to-sky-200 p-8">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Program Dashboard</h1>
        <div className="flex items-center gap-4">
          <MyAccount onNavigate={handleNavigate} />
        </div>
      </header>

      <MainApp />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <InnerApp />
    </AuthProvider>
  );
}