import React, { useState, useRef, useEffect } from "react";
import { useAuth } from "../AuthContext";

/**
 * MyAccount
 *
 * Shows either:
 * - Sign in / Sign up form when not authenticated (delegates to AuthForm via link)
 * - A small dropdown when authenticated with quick links ("My programs", "Settings") and Sign out.
 *
 * Props:
 * - onNavigate(optional): function(route) - called when user clicks "My programs" or "Settings".
 *
 * Place this component in the header where AuthForm was previously shown.
 */
export default function MyAccount({ onNavigate }) {
  const { user, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const ref = useRef();

  useEffect(() => {
    function onDoc(e) {
      if (!ref.current) return;
      if (!ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("click", onDoc);
    return () => document.removeEventListener("click", onDoc);
  }, []);

  if (!user) {
    // Simple fallback to the existing AuthForm UI route: show link to open auth modal or direct user to sign-in area.
    // If your app used AuthForm inline, keep it. Here we provide a small link to the sign-in form.
    return (
      <div className="flex items-center gap-3">
        <a href="#signin" className="px-3 py-1 bg-white text-emerald rounded shadow-sm">Sign in / Sign up</a>
      </div>
    );
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-3 bg-white px-3 py-2 rounded text-emerald shadow-sm hover:opacity-95"
        aria-haspopup="true"
        aria-expanded={open}
      >
        <div className="w-8 h-8 rounded-full bg-emerald/20 flex items-center justify-center text-emerald font-semibold">
          {user.email ? user.email.charAt(0).toUpperCase() : "U"}
        </div>
        <div className="hidden sm:block text-left">
          <div className="text-xs text-gray-600">Signed in as</div>
          <div className="text-sm font-medium">{user.email}</div>
        </div>
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded shadow-lg border z-50">
          <nav className="flex flex-col p-2">
            <button
              className="text-left px-3 py-2 rounded hover:bg-gray-50 text-sm"
              onClick={() => {
                setOpen(false);
                if (onNavigate) onNavigate("programs");
                else window.location.hash = "#programs";
              }}
            >
              My programs
            </button>

            <button
              className="text-left px-3 py-2 rounded hover:bg-gray-50 text-sm"
              onClick={() => {
                setOpen(false);
                if (onNavigate) onNavigate("settings");
                else window.location.hash = "#settings";
              }}
            >
              Settings
            </button>

            <div className="border-t my-1" />

            <button
              className="text-left px-3 py-2 rounded hover:bg-gray-50 text-sm text-red-600"
              onClick={async () => {
                setOpen(false);
                try {
                  await signOut();
                } catch (err) {
                  console.error("Sign out failed", err);
                }
              }}
            >
              Sign out
            </button>
          </nav>
        </div>
      )}
    </div>
  );
}