import React, { useRef } from "react";
import Papa from "papaparse";

/**
 * CSVControls
 *
 * Props:
 * - onExport(filteredPrograms) => void
 * - onImport(parsedProgramsArray) => void (each item is a program object)
 *
 * Note: Import expects CSV with headers: 'Type Program' | 'Brand' | 'Pencapaian'
 */
export default function CSVControls({ onExport, onImport }) {
  const fileRef = useRef();

  function handleExportClick() {
    onExport();
  }

  function handleFileChange(e) {
    const f = e.target.files[0];
    if (!f) return;
    Papa.parse(f, {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        const rows = results.data;
        // Validate headers presence
        const requiredHeaders = ["Type Program", "Brand", "Pencapaian"];
        const headers = results.meta.fields || [];
        const missing = requiredHeaders.filter((h) => !headers.includes(h));
        if (missing.length) {
          alert(`Missing required CSV headers: ${missing.join(", ")}`);
          fileRef.current.value = "";
          return;
        }

        // Map rows to minimal program objects
        const programs = rows.map((r, idx) => {
          const type = (r["Type Program"] || "").toString().trim();
          const brand = (r["Brand"] || "").toString().trim();
          const pencapaianRaw = r["Pencapaian"] || "";
          const achievement = Number(pencapaianRaw.toString().replace(/[^0-9.\-]/g, "")) || 0;

          return {
            // App will generate its own ID; we provide fallbacks here
            importedRowIndex: idx,
            type,
            brand,
            achievement,
          };
        });

        onImport(programs);
        fileRef.current.value = "";
      },
      error: function (err) {
        alert("Failed to parse CSV: " + err.message);
        fileRef.current.value = "";
      },
    });
  }

  return (
    <div className="flex items-center gap-3">
      <button
        onClick={handleExportClick}
        className="px-3 py-2 bg-sky text-white rounded hover:bg-sky-600"
      >
        Export CSV
      </button>

      <label className="px-3 py-2 bg-emerald text-white rounded cursor-pointer hover:bg-emerald-600">
        Import CSV
        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          onChange={handleFileChange}
          className="hidden"
        />
      </label>
    </div>
  );
}