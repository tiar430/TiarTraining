import React, { useEffect, useMemo, useState } from "react";
import Modal from "./Modal";

/**
 * ProgramFormModal
 *
 * Props:
 * - isOpen
 * - onClose
 * - onSave(programObject)
 * - initialData (for edit) or null (for add)
 * - brands: array of strings
 * - programTypes: array of strings
 */
export default function ProgramFormModal({
  isOpen,
  onClose,
  onSave,
  initialData = null,
  brands = [],
  programTypes = [],
}) {
  const isEdit = Boolean(initialData);

  // default form state
  const [form, setForm] = useState({
    id: "",
    type: "",
    description: "",
    brand: "",
    start: "",
    end: "",
    target: "",
    targetPercent: "",
    achievement: "",
    rewardAmount: "",
    rewardPercent: "",
    status: "Pending",
    paymentStatus: "Unpaid",
  });

  useEffect(() => {
    if (isOpen) {
      // if editing, populate form; otherwise reset & generate ID
      if (initialData) {
        setForm({
          id: initialData.id || generateProgramId(),
          type: initialData.type || "",
          description: initialData.description || "",
          brand: initialData.brand || (brands[0] || ""),
          start: initialData.start || "",
          end: initialData.end || "",
          target: initialData.target ?? "",
          targetPercent: initialData.targetPercent ?? "",
          achievement: initialData.achievement ?? "",
          rewardAmount: initialData.rewardAmount ?? "",
          rewardPercent: initialData.rewardPercent ?? "",
          status: initialData.status || "Pending",
          paymentStatus: initialData.paymentStatus || "Unpaid",
        });
      } else {
        setForm((f) => ({
          ...f,
          id: generateProgramId(),
          brand: brands[0] || "",
          type: programTypes[0] || "",
        }));
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, initialData]);

  // helpers
  function updateField(key, value) {
    setForm((s) => ({ ...s, [key]: value }));
  }

  function generateProgramId() {
    const ts = Date.now().toString(36).toUpperCase();
    const rand = Math.floor(Math.random() * 900 + 100); // 3-digit
    return `PRG-${ts}-${rand}`;
  }

  // Calculations derived from form - memoized
  const calculated = useMemo(() => {
    const target = Number(form.target) || 0;
    const achievement = Number(form.achievement) || 0;
    const rewardAmount = Number(form.rewardAmount) || 0;
    const rewardPercent = Number(form.rewardPercent) || 0;

    const estimatedRewardFromAmount = achievement * rewardAmount;
    // rewardPercent interpreted as "per-unit percent" -> estimated from percent = achievement * (rewardPercent / 100)
    const estimatedRewardFromPercent = achievement * (rewardPercent / 100);

    // If both entered, prefer absolute amount as primary estimate; still expose both
    const estimatedReward =
      rewardAmount > 0 ? estimatedRewardFromAmount : estimatedRewardFromPercent;

    const remainingTarget = target - achievement;

    // time gone % between start and end relative to now
    let timeGonePercent = 0;
    if (form.start && form.end) {
      const startT = new Date(form.start).getTime();
      const endT = new Date(form.end).getTime();
      const now = Date.now();
      if (endT > startT) {
        timeGonePercent = ((now - startT) / (endT - startT)) * 100;
      } else {
        timeGonePercent = 100;
      }
      if (timeGonePercent < 0) timeGonePercent = 0;
      if (timeGonePercent > 100) timeGonePercent = 100;
    }

    const progressPercent = target > 0 ? (achievement / target) * 100 : 0;

    return {
      target,
      achievement,
      rewardAmount,
      rewardPercent,
      estimatedReward,
      estimatedRewardFromAmount,
      estimatedRewardFromPercent,
      remainingTarget,
      timeGonePercent: Math.round(timeGonePercent * 10) / 10,
      progressPercent: Math.round(progressPercent * 10) / 10,
    };
  }, [form]);

  // basic validation
  function validate() {
    const errors = [];
    if (!form.type) errors.push("Type Program is required.");
    if (!form.brand) errors.push("Brand is required.");
    if (!form.start) errors.push("Periode Start is required.");
    if (!form.end) errors.push("Periode End is required.");
    if (!form.target && !form.targetPercent) errors.push("Target Program is required.");
    // allow target percentage or numeric target
    const startT = form.start ? new Date(form.start).getTime() : null;
    const endT = form.end ? new Date(form.end).getTime() : null;
    if (startT && endT && endT < startT) errors.push("Periode End must be after Periode Start.");
    return errors;
  }

  function handleSave(e) {
    e.preventDefault();
    const errors = validate();
    if (errors.length) {
      alert(errors.join("\n"));
      return;
    }
    // build program object
    const program = {
      id: form.id,
      type: form.type,
      description: form.description,
      brand: form.brand,
      start: form.start,
      end: form.end,
      target: calculated.target,
      targetPercent: form.targetPercent,
      achievement: calculated.achievement,
      rewardAmount: calculated.rewardAmount,
      rewardPercent: calculated.rewardPercent,
      estimatedReward: calculated.estimatedReward,
      remainingTarget: calculated.remainingTarget,
      timeGonePercent: calculated.timeGonePercent,
      progressPercent: calculated.progressPercent,
      status: form.status,
      paymentStatus: form.paymentStatus,
      // store raw input strings too for audit
      raw: { ...form },
    };

    onSave(program);
    onClose();
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={isEdit ? "Edit Program" : "Add Program"}>
      <form onSubmit={handleSave} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Program ID (auto)</label>
            <input
              className="mt-1 w-full p-2 border rounded bg-gray-50"
              value={form.id}
              readOnly
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Type Program</label>
            <select
              className="mt-1 w-full p-2 border rounded"
              value={form.type}
              onChange={(e) => updateField("type", e.target.value)}
            >
              <option value="">-- Select Type --</option>
              {programTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          <div className="col-span-2">
            <label className="block text-sm font-medium">Keterangan</label>
            <input
              className="mt-1 w-full p-2 border rounded"
              value={form.description}
              onChange={(e) => updateField("description", e.target.value)}
              placeholder="Keterangan singkat..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Brand</label>
            <select
              className="mt-1 w-full p-2 border rounded"
              value={form.brand}
              onChange={(e) => updateField("brand", e.target.value)}
            >
              <option value="">-- Select Brand --</option>
              {brands.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium">Status Program</label>
            <select
              className="mt-1 w-full p-2 border rounded"
              value={form.status}
              onChange={(e) => updateField("status", e.target.value)}
            >
              <option>Active</option>
              <option>Pending</option>
              <option>Ended</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium">Periode Start</label>
            <input
              type="date"
              className="mt-1 w-full p-2 border rounded"
              value={form.start}
              onChange={(e) => updateField("start", e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Periode End</label>
            <input
              type="date"
              className="mt-1 w-full p-2 border rounded"
              value={form.end}
              onChange={(e) => updateField("end", e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Target Program (number)</label>
            <input
              type="number"
              className="mt-1 w-full p-2 border rounded"
              value={form.target}
              onChange={(e) => updateField("target", e.target.value)}
              min="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Target (persentase)</label>
            <input
              type="number"
              className="mt-1 w-full p-2 border rounded"
              value={form.targetPercent}
              onChange={(e) => updateField("targetPercent", e.target.value)}
              min="0"
              max="100"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Pencapaian program</label>
            <input
              type="number"
              className="mt-1 w-full p-2 border rounded"
              value={form.achievement}
              onChange={(e) => updateField("achievement", e.target.value)}
              min="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Reward - Amount per unit</label>
            <input
              type="number"
              className="mt-1 w-full p-2 border rounded"
              value={form.rewardAmount}
              onChange={(e) => updateField("rewardAmount", e.target.value)}
              min="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Reward - Percent</label>
            <input
              type="number"
              className="mt-1 w-full p-2 border rounded"
              value={form.rewardPercent}
              onChange={(e) => updateField("rewardPercent", e.target.value)}
              min="0"
              max="100"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Status Pembayaran</label>
            <select
              className="mt-1 w-full p-2 border rounded"
              value={form.paymentStatus}
              onChange={(e) => updateField("paymentStatus", e.target.value)}
            >
              <option>Paid</option>
              <option>Unpaid</option>
              <option>Partial</option>
            </select>
          </div>
        </div>

        {/* Calculations & progress */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 p-3 rounded">
            <div className="text-sm font-medium text-gray-600">Estimated Reward</div>
            <div className="text-lg font-bold mt-1">
              {formatCurrency(calculated.estimatedReward)}{" "}
              <span className="text-xs text-gray-500 ml-2">
                (from amount: {formatCurrency(calculated.estimatedRewardFromAmount)}, percent:{" "}
                {formatCurrency(calculated.estimatedRewardFromPercent)})
              </span>
            </div>
            <div className="mt-3">
              <div className="text-sm text-gray-600">Remaining Target</div>
              <div className="font-semibold">{calculated.remainingTarget}</div>
            </div>
          </div>

          <div className="bg-gray-50 p-3 rounded">
            <div>
              <div className="text-sm font-medium text-gray-600">Target Progress</div>
              <div className="text-xs text-gray-500">{calculated.progressPercent}%</div>
              <div className="w-full bg-gray-200 h-3 rounded mt-1">
                <div
                  className="h-3 rounded bg-emerald"
                  style={{ width: `${Math.min(calculated.progressPercent, 100)}%` }}
                />
              </div>
            </div>

            <div className="mt-3">
              <div className="text-sm font-medium text-gray-600">Time Gone</div>
              <div className="text-xs text-gray-500">{calculated.timeGonePercent}%</div>
              <div className="w-full bg-gray-200 h-3 rounded mt-1">
                <div
                  className="h-3 rounded bg-sky-500"
                  style={{ width: `${Math.min(calculated.timeGonePercent, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded border text-sm"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 rounded text-white bg-emerald hover:bg-emerald/90"
          >
            {isEdit ? "Save Changes" : "Create Program"}
          </button>
        </div>
      </form>
    </Modal>
  );
}

// small helper
function formatCurrency(v) {
  if (!v && v !== 0) return "Rp 0";
  // simple local format - adapt to real locale if needed
  return "Rp " + Number(v).toLocaleString();
}