// src/components/AuthForm.jsx
// Simple sign up / sign in form. Use inside your App header or a dedicated route.
import React, { useState } from "react";
import { useAuth } from "../AuthContext";

export default function AuthForm() {
  const { user, signUp, signIn, signOut } = useAuth();
  const [mode, setMode] = useState("signIn"); // signIn or signUp
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signUp") {
        await signUp({ email, password });
        alert("Sign-up successful. Check your email if confirmation is required.");
      } else {
        await signIn({ email, password });
      }
      setEmail("");
      setPassword("");
    } catch (err) {
      console.error(err);
      alert(err.message || "Auth failed");
    } finally {
      setBusy(false);
    }
  }

  if (user) {
    return (
      <div className="flex items-center gap-3">
        <div className="text-white">Signed in as <strong>{user.email}</strong></div>
        <button onClick={() => signOut()} className="px-3 py-1 bg-white text-emerald rounded">Sign out</button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-3">
      <select value={mode} onChange={(e) => setMode(e.target.value)} className="p-2 rounded">
        <option value="signIn">Sign In</option>
        <option value="signUp">Sign Up</option>
      </select>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="p-2 rounded" required />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="p-2 rounded" required />
      <button type="submit" disabled={busy} className="px-3 py-1 bg-white text-emerald rounded">
        {busy ? "Please wait..." : mode === "signUp" ? "Sign up" : "Sign in"}
      </button>
    </form>
  );
}