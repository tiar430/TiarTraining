import React from "react";

/**
 * FilterBar
 *
 * Props:
 * - brands: array of brand strings
 * - selectedBrand: string (current filter)
 * - onBrandChange(brand)
 * - searchQuery: string
 * - onSearchChange(q)
 */
export default function FilterBar({ brands = [], selectedBrand = "All", onBrandChange, searchQuery = "", onSearchChange }) {
  return (
    <div className="bg-white rounded shadow p-4 mb-6 flex flex-col md:flex-row md:items-center md:gap-4">
      <div className="flex items-center gap-3 mb-3 md:mb-0">
        <label className="text-sm font-medium text-gray-700">Brand</label>
        <select
          className="p-2 border rounded"
          value={selectedBrand}
          onChange={(e) => onBrandChange(e.target.value)}
        >
          <option value="All">All</option>
          {brands.map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </select>
      </div>

      <div className="flex items-center gap-3 flex-1">
        <label className="text-sm font-medium text-gray-700">Search Type Program</label>
        <input
          type="search"
          className="flex-1 p-2 border rounded"
          placeholder="Cari Type Program..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
    </div>
  );
}