// src/api.js
// API client updated to accept/set JWT (access token). The React AuthContext stores token and
// calls setAuthToken when session changes.
//
// Usage:
// import api from './api';
// api.setAuthToken(token);
// api.createProgram({...});
const API_BASE = process.env.REACT_APP_API_BASE_URL || "";

let authToken = null;

export function setAuthToken(token) {
  authToken = token;
}

async function handleJSONResponse(res) {
  const text = await res.text();
  try {
    return text ? JSON.parse(text) : null;
  } catch {
    return text;
  }
}

function buildHeaders(extra = {}) {
  const headers = { "Content-Type": "application/json", ...extra };
  if (authToken) headers["Authorization"] = `Bearer ${authToken}`;
  return headers;
}

export async function getPrograms({ brand = "All", search = "" } = {}) {
  const params = new URLSearchParams();
  if (brand) params.set("brand", brand);
  if (search) params.set("search", search);
  const url = `${API_BASE}/api/programs?${params.toString()}`;
  const res = await fetch(url, { headers: buildHeaders() });
  if (!res.ok) throw new Error(`Failed to fetch programs: ${res.status}`);
  return handleJSONResponse(res);
}

export async function getProgram(id) {
  const res = await fetch(`${API_BASE}/api/programs/${encodeURIComponent(id)}`, { headers: buildHeaders() });
  if (!res.ok) throw new Error("Failed to fetch program");
  return handleJSONResponse(res);
}

export async function createProgram(program) {
  const res = await fetch(`${API_BASE}/api/programs`, {
    method: "POST",
    headers: buildHeaders(),
    body: JSON.stringify(program),
  });
  if (!res.ok) {
    const err = await handleJSONResponse(res);
    throw new Error(err?.error || "Failed to create program");
  }
  return handleJSONResponse(res);
}

export async function updateProgram(id, program) {
  const res = await fetch(`${API_BASE}/api/programs/${encodeURIComponent(id)}`, {
    method: "PUT",
    headers: buildHeaders(),
    body: JSON.stringify(program),
  });
  if (!res.ok) {
    const err = await handleJSONResponse(res);
    throw new Error(err?.error || "Failed to update program");
  }
  return handleJSONResponse(res);
}

export async function deleteProgram(id) {
  const res = await fetch(`${API_BASE}/api/programs/${encodeURIComponent(id)}`, {
    method: "DELETE",
    headers: buildHeaders(),
  });
  if (!res.ok) {
    const err = await handleJSONResponse(res);
    throw new Error(err?.error || "Failed to delete program");
  }
  return handleJSONResponse(res);
}

export async function exportCSV({ brand = "All", search = "" } = {}) {
  const params = new URLSearchParams();
  if (brand) params.set("brand", brand);
  if (search) params.set("search", search);
  const url = `${API_BASE}/api/export?${params.toString()}`;
  const res = await fetch(url, { headers: buildHeaders() });
  if (!res.ok) {
    const err = await handleJSONResponse(res);
    throw new Error(err?.error || "Failed to export CSV");
  }
  return res.blob();
}

export async function callNotify(notifyApiKey) {
  const res = await fetch(`${API_BASE}/api/notify`, {
    method: "POST",
    headers: { ...buildHeaders(), "x-notify-api-key": notifyApiKey || "" },
    body: JSON.stringify({}),
  });
  return handleJSONResponse(res);
}

export default {
  setAuthToken,
  getPrograms,
  getProgram,
  createProgram,
  updateProgram,
  deleteProgram,
  exportCSV,
  callNotify,
};