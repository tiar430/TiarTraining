-- server/db_rls.sql
-- Add owner_id, enable RLS, and create policies for per-user ownership.
-- Run this in the Supabase SQL editor (or psql) after creating the programs table.
-- NOTE: These policies assume users authenticate via Supabase Auth.

-- add owner_id column (uuid) if not present
ALTER TABLE IF EXISTS programs
  ADD COLUMN IF NOT EXISTS owner_id uuid;

-- update existing rows to a placeholder owner if desired (skip if you prefer manual migration)
-- UPDATE programs SET owner_id = '00000000-0000-0000-0000-000000000000' WHERE owner_id IS NULL;

-- enable row level security
ALTER TABLE IF EXISTS programs ENABLE ROW LEVEL SECURITY;

-- drop policies if exist (idempotent)
DROP POLICY IF EXISTS "Owner access" ON programs;

-- policy to allow owners to SELECT
CREATE POLICY "Owner access - select" ON programs
  FOR SELECT
  USING (owner_id = auth.uid());

-- policy to allow owners to INSERT (with owner set to auth.uid())
CREATE POLICY "Owner access - insert" ON programs
  FOR INSERT
  WITH CHECK (owner_id = auth.uid());

-- policy to allow owners to UPDATE
CREATE POLICY "Owner access - update" ON programs
  FOR UPDATE
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- policy to allow owners to DELETE
CREATE POLICY "Owner access - delete" ON programs
  FOR DELETE
  USING (owner_id = auth.uid());

-- index on owner_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_programs_owner_id ON programs (owner_id);