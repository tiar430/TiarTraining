/**
 * server/index.js
 * Express API that uses Supabase (service role) for data persistence and nodemailer for email notifications.
 *
 * Endpoints:
 * - GET  /api/programs            (list, supports ?brand=&search=)
 * - GET  /api/programs/:id        (get single)
 * - POST /api/programs            (create)
 * - PUT  /api/programs/:id        (update)
 * - DELETE /api/programs/:id      (delete)
 * - GET  /api/export              (returns CSV of current filter)
 * - POST /api/notify              (check near-end programs and send emails) - protected by NOTIFY_API_KEY
 *
 * Environment variables:
 * SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY,
 * SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS, EMAIL_FROM,
 * NOTIFY_API_KEY, NOTIFY_DAYS_BEFORE_END
 */
// server/index.js (modified parts)
// server verifies Authorization: Bearer <access_token> and uses Supabase auth.getUser to retrieve user.
// then attaches owner_id to created/updated program records.
//
// NOTE: this file is an update to your existing server/index.js: I added auth middleware and
// applied the owner_id handling on endpoints that create/read/modify programs.

import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";
import nodemailer from "nodemailer";
import { stringify } from "csv-stringify";
import { addDays, parseISO, differenceInCalendarDays } from "date-fns";

dotenv.config();

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing Supabase config. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env");
  process.exit(1);
}
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

const SMTP_HOST = process.env.SMTP_HOST;
const SMTP_PORT = Number(process.env.SMTP_PORT || 587);
const SMTP_SECURE = (process.env.SMTP_SECURE || "false") === "true";
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const EMAIL_FROM = process.env.EMAIL_FROM || "no-reply@example.com";
const NOTIFY_API_KEY = process.env.NOTIFY_API_KEY || "changeme";
const NOTIFY_DAYS = Number(process.env.NOTIFY_DAYS_BEFORE_END || 3);

const transporter = nodemailer.createTransport({
  host: SMTP_HOST,
  port: SMTP_PORT,
  secure: SMTP_SECURE,
  auth: {
    user: SMTP_USER,
    pass: SMTP_PASS,
  },
});

async function sendEmail(to, subject, html) {
  const info = await transporter.sendMail({
    from: EMAIL_FROM,
    to,
    subject,
    html,
  });
  return info;
}

const app = express();
app.use(cors());
app.use(bodyParser.json());

// --- auth helper middleware ---
async function getUserFromAuthHeader(req) {
  const auth = req.headers.authorization;
  if (!auth) return null;
  const token = auth.split(" ")[1];
  if (!token) return null;
  try {
    // supabase.auth.getUser accepts the access token on the server with service role key
    const { data, error } = await supabase.auth.getUser(token);
    if (error) {
      console.warn("supabase.auth.getUser error:", error.message);
      return null;
    }
    return data?.user || null;
  } catch (err) {
    console.error("getUserFromAuthHeader err:", err);
    return null;
  }
}

// protect route middleware
function requireAuth(handler) {
  return async (req, res) => {
    const user = await getUserFromAuthHeader(req);
    if (!user) return res.status(401).json({ error: "Not authenticated" });
    req.user = user;
    return handler(req, res);
  };
}

// reuse your normalize function as before (slightly modified)
function normalizeProgramRow(row) {
  const target = Number(row.target) || 0;
  const achievement = Number(row.achievement) || 0;
  const rewardAmount = Number(row.reward_amount || row.rewardAmount) || 0;
  const rewardPercent = Number(row.reward_percent || row.rewardPercent) || 0;

  const estimatedFromAmount = achievement * rewardAmount;
  const estimatedFromPercent = achievement * (rewardPercent / 100);
  const estimated = rewardAmount > 0 ? estimatedFromAmount : estimatedFromPercent;

  let progressPercent = target > 0 ? (achievement / target) * 100 : 0;
  let remainingTarget = target - achievement;

  return {
    ...row,
    target,
    achievement,
    reward_amount: rewardAmount,
    reward_percent: rewardPercent,
    estimated_reward: Math.round(estimated),
    estimated_reward_from_amount: Math.round(estimatedFromAmount),
    estimated_reward_from_percent: Math.round(estimatedFromPercent),
    progress_percent: Math.round(progressPercent * 10) / 10,
    remaining_target: remainingTarget,
  };
}

// GET /api/programs - returns programs owned by the authenticated user
app.get("/api/programs", requireAuth(async (req, res) => {
  try {
    const { brand, search } = req.query;
    // fetch programs owned by this user using supabase with service role, but filter on owner_id
    const { data, error } = await supabase
      .from("programs")
      .select("*")
      .eq("owner_id", req.user.id)
      .order("created_at", { ascending: false });

    if (error) throw error;

    let result = data || [];
    if (brand && brand !== "All") result = result.filter((p) => p.brand === brand);
    if (search) {
      const q = String(search).toLowerCase();
      result = result.filter((p) => (p.type || "").toLowerCase().includes(q));
    }
    result = result.map((r) => normalizeProgramRow(r));
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch programs" });
  }
}));

// GET single program - restrict to owner
app.get("/api/programs/:id", requireAuth(async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error } = await supabase.from("programs").select("*").eq("id", id).single();
    if (error) throw error;
    if (data.owner_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });
    res.json(normalizeProgramRow(data));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch program" });
  }
}));

// POST create (owner_id will be set to authenticated user)
app.post("/api/programs", requireAuth(async (req, res) => {
  try {
    const payload = req.body || {};
    const id = payload.id || `PRG-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 900 + 100)}`;
    const normalized = normalizeProgramRow({ ...payload, id });

    const insert = {
      id: normalized.id,
      type: normalized.type,
      description: normalized.description,
      brand: normalized.brand,
      start_date: normalized.start,
      end_date: normalized.end,
      target: normalized.target,
      target_percent: normalized.target_percent,
      achievement: normalized.achievement,
      reward_amount: normalized.reward_amount,
      reward_percent: normalized.reward_percent,
      estimated_reward: normalized.estimated_reward,
      remaining_target: normalized.remaining_target,
      progress_percent: normalized.progress_percent,
      time_gone_percent: normalized.time_gone_percent || 0,
      status: normalized.status || "Pending",
      payment_status: normalized.payment_status || "Unpaid",
      owner_id: req.user.id,
    };

    const { data, error } = await supabase.from("programs").insert([insert]).select().single();
    if (error) throw error;
    res.status(201).json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create program" });
  }
}));

// PUT update - ensure owner matches
app.put("/api/programs/:id", requireAuth(async (req, res) => {
  try {
    const { id } = req.params;
    // fetch current row to verify ownership
    const { data: existing, error: e1 } = await supabase.from("programs").select("*").eq("id", id).single();
    if (e1) throw e1;
    if (!existing || existing.owner_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });

    const payload = req.body || {};
    const normalized = normalizeProgramRow({ ...existing, ...payload });

    const update = {
      type: normalized.type,
      description: normalized.description,
      brand: normalized.brand,
      start_date: normalized.start,
      end_date: normalized.end,
      target: normalized.target,
      target_percent: normalized.target_percent,
      achievement: normalized.achievement,
      reward_amount: normalized.reward_amount,
      reward_percent: normalized.reward_percent,
      estimated_reward: normalized.estimated_reward,
      remaining_target: normalized.remaining_target,
      progress_percent: normalized.progress_percent,
      time_gone_percent: normalized.time_gone_percent || 0,
      status: normalized.status,
      payment_status: normalized.payment_status,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase.from("programs").update(update).eq("id", id).select().single();
    if (error) throw error;
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update program" });
  }
}));

// DELETE - ensure owner matches
app.delete("/api/programs/:id", requireAuth(async (req, res) => {
  try {
    const { id } = req.params;
    const { data: existing, error: e1 } = await supabase.from("programs").select("*").eq("id", id).single();
    if (e1) throw e1;
    if (!existing || existing.owner_id !== req.user.id) return res.status(403).json({ error: "Forbidden" });

    const { data, error } = await supabase.from("programs").delete().eq("id", id);
    if (error) throw error;
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete program" });
  }
}));

// GET export - only owner's programs
app.get("/api/export", requireAuth(async (req, res) => {
  try {
    const { brand, search } = req.query;
    const { data, error } = await supabase.from("programs").select("*").eq("owner_id", req.user.id);
    if (error) throw error;
    let rows = data || [];
    if (brand && brand !== "All") rows = rows.filter((p) => p.brand === brand);
    if (search) {
      const q = String(search).toLowerCase();
      rows = rows.filter((p) => (p.type || "").toLowerCase().includes(q));
    }

    const headerRow = [
      "Program ID",
      "Type Program",
      "Brand",
      "Pencapaian",
      "Target",
      "Estimated Reward",
      "Status Program",
      "Status Pembayaran",
      "Periode Start",
      "Periode End",
    ];

    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="programs_export_${Date.now()}.csv"`);

    const stringifier = stringify({ header: true, columns: headerRow });
    stringifier.pipe(res);
    rows.forEach((r) =>
      stringifier.write([
        r.id,
        r.type,
        r.brand,
        r.achievement,
        r.target,
        r.estimated_reward,
        r.status,
        r.payment_status,
        r.start_date ? r.start_date.toString() : "",
        r.end_date ? r.end_date.toString() : "",
      ])
    );
    stringifier.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to export CSV" });
  }
}));

// POST /api/notify - protected by NOTIFY_API_KEY, wildcards: notify owner's programs? For now it sends to NOTIFY_TO_EMAIL
app.post("/api/notify", async (req, res) => {
  try {
    const key = req.headers["x-notify-api-key"];
    if (key !== NOTIFY_API_KEY) {
      return res.status(403).json({ error: "Forbidden" });
    }

    // fetch all programs (service role) and filter by end_date within NOTIFY_DAYS
    const { data: allPrograms, error } = await supabase.from("programs").select("*");
    if (error) throw error;

    const now = new Date();
    const candidates = (allPrograms || []).filter((p) => {
      if (!p.end_date) return false;
      if (p.status === "Ended") return false;
      const endDate = typeof p.end_date === "string" ? parseISO(p.end_date) : new Date(p.end_date);
      const daysLeft = differenceInCalendarDays(endDate, now);
      return daysLeft >= 0 && daysLeft <= NOTIFY_DAYS;
    });

    if (!candidates.length) {
      return res.json({ sent: 0, message: "No near-end programs" });
    }

    const recipient = process.env.NOTIFY_TO_EMAIL;
    if (!recipient) {
      console.warn("NOTIFY_TO_EMAIL not set - skipping send");
      return res.json({ found: candidates.length, sent: 0, details: "NO_RECIPIENT_CONFIGURED" });
    }

    const bodyItems = candidates.map((p) => {
      const endDate = p.end_date ? new Date(p.end_date).toISOString().slice(0, 10) : "N/A";
      return `<li><strong>${p.type}</strong> (ID: ${p.id}) - Brand: ${p.brand || "N/A"} - End: ${endDate} - Progress: ${p.progress_percent ?? 0}%</li>`;
    }).join("");

    const html = `<p>Programs ending within ${NOTIFY_DAYS} days:</p><ul>${bodyItems}</ul>`;

    const info = await sendEmail(recipient, `Programs near end (within ${NOTIFY_DAYS} days)`, html);

    res.json({ sent: 1, messageId: info.messageId, count: candidates.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to send notifications", details: err.message });
  }
});

const PORT = Number(process.env.PORT || 8080);
app.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});