```markdown
# Program Dashboard - Server (Express + Supabase + Nodemailer)

Overview
- Provides REST endpoints for Programs: CRUD + CSV export + notify (near-end emails)
- Uses Supabase Postgres (free tier) for storage and Supabase Auth for user management.
- Uses SMTP (Sendinblue/Gmail/Mailgun) via nodemailer to send email alerts.
- Scheduling: Use GitHub Actions (provided) to call /api/notify daily (no always-on server needed).

Prerequisites
- Node 18+
- Supabase project (https://supabase.com) — free tier is fine.
  - Create a project and a database.
  - Note SUPABASE_URL and SERVICE_ROLE_KEY (found in Project Settings → API). Keep SERVICE_ROLE_KEY secret (server-only).
  - Optional: Use Supabase Auth (email/password) for sign-up/login; you can then use client-side supabase auth in frontend.
- SMTP credentials (Sendinblue / Mailgun / Gmail SMTP). Example env vars below.
- GitHub repo to use the included workflow, or schedule via any cron service.

Environment variables (server .env)
- SUPABASE_URL=your-supabase-url
- SUPABASE_SERVICE_ROLE_KEY=your-supabase-service-role-key
- SMTP_HOST=smtp.example.com
- SMTP_PORT=587
- SMTP_SECURE=false
- SMTP_USER=your-smtp-username
- SMTP_PASS=your-smtp-password
- NOTIFY_API_KEY=some-secret-token-for-workflow
- EMAIL_FROM="Program Dashboard <no-reply@example.com>"
- NOTIFY_DAYS_BEFORE_END=3    # number of days before end-date to notify

Local dev
1. cd server
2. npm install
3. copy .env.example -> .env and fill values
4. Run DB migration: psql to Supabase DB or use SQL editor in Supabase and run server/db.sql
5. Start server: npm start
6. Use Postman or curl to call endpoints.

Deploy
- Deploy to Railway/Vercel/Render using the environment variables above.
- Or deploy only the notify endpoint as a serverless function and use GitHub Actions to call it.

Security note
- Keep SUPABASE_SERVICE_ROLE_KEY and NOTIFY_API_KEY secret (never expose to frontend).
- Use Supabase Auth from the frontend for multi-user sign-in. Use Supabase row-level security as needed.

```
# Program Dashboard — Quick Deploy Guide

This README provides concise deployment steps for the server (Express + Supabase) and the frontend (React) using free-tier friendly platforms: Railway or Render for the server and Vercel for the frontend.

Note: This guide assumes you've already created a Supabase project and configured the database schema (see server/db.sql and server/db_rls.sql in the repo).

---

## 1) Prerequisites

- Node.js 18+ installed locally
- A Supabase project:
  - SUPABASE_URL
  - SUPABASE_SERVICE_ROLE_KEY (server-only secret)
  - SUPABASE_ANON_KEY (frontend)
- SMTP credentials for sending email (Sendinblue/Mailgun/Gmail App Password)
- GitHub repository (recommended) for using GitHub Actions schedule (optional)

---

## 2) Server (Railway or Render)

You can deploy the server to Railway or Render. Both offer free tiers suitable for small apps.

Common steps (works for both):

1. In your repo, ensure `server/index.js` and `server/package.json` are present.
2. Create a new project on Railway or Render and connect it to your GitHub repo (or push code manually).
3. In the service settings, set the environment variables:

- SUPABASE_URL=https://...supabase.co
- SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
- SMTP_HOST=smtp.example.com
- SMTP_PORT=587
- SMTP_SECURE=false
- SMTP_USER=...
- SMTP_PASS=...
- EMAIL_FROM="Program Dashboard <no-reply@example.com>"
- NOTIFY_API_KEY=a-strong-random-string
- NOTIFY_TO_EMAIL=your-notify-recipient@example.com
- NOTIFY_DAYS_BEFORE_END=3
- PORT=8080 (Railway/Render override automatically)

4. (Optional) On Supabase, open the SQL editor and run:
   - `server/db.sql` to create the `programs` table.
   - `server/db_rls.sql` to add `owner_id` and enable RLS policies.

5. Deploy:
   - Railway: Create a new project → "Deploy from GitHub" → pick repo and `server` service root. Railway will install and start with `npm start`.
   - Render: New Web Service → Connect repo → Build command `npm install` (or `npm ci`) and Start command `npm start`. Ensure the root points to the `server` directory or create a Render service from the `server` folder.

6. After deployment, note the server base URL (e.g., `https://your-server.up.railway.app`).

Security notes:
- Keep `SUPABASE_SERVICE_ROLE_KEY` and SMTP credentials secret (use the platform's secret env var settings).
- `NOTIFY_API_KEY` is used to protect the `/api/notify` endpoint. Store it in GitHub Secrets for the Action below.

---

## 3) Frontend (Vercel)

Vercel has a generous free tier and is ideal for React apps.

1. Ensure your React app is in the repo root (or a `client` folder). The frontend should include `.env.local` values referenced below during local dev, but never commit `.env.local`.

2. In Vercel, create a new project -> import from GitHub -> select your repo.

3. Set Environment Variables in the Vercel project (Settings → Environment Variables):

- REACT_APP_SUPABASE_URL=https://your-project.supabase.co
- REACT_APP_SUPABASE_ANON_KEY=your-anon-key
- REACT_APP_API_BASE_URL=https://your-server-domain (the server URL from Railway/Render)

4. Build & Output settings:
- Framework Preset: Create React App (Vercel usually detects automatically).
- Build Command: `npm run build` (or leave default)
- Output Directory: `build` (CRA default)

5. Deploy: Vercel will build and deploy on push to the main branch.

---

## 4) GitHub Actions: Scheduled Notify

If you want daily email alerts without running a cron server, use the included workflow `.github/workflows/daily_notify.yml`.

1. In GitHub repo Secrets, add:
- NOTIFY_URL=https://your-server-domain/api/notify
- NOTIFY_API_KEY=the-same-key-you-set-in-server-env

2. The workflow runs daily and POSTs to the notify endpoint with `x-notify-api-key` header.

---

## 5) Local Development

Run server locally:
- cd server
- copy `.env.example` -> `.env` and fill values
- npm install
- npm start
- Server runs at http://localhost:8080 by default

Run frontend locally:
- cd frontend (or repo root if CRA there)
- copy `.env.local.example` -> `.env.local` and add:
  - REACT_APP_SUPABASE_URL=
  - REACT_APP_SUPABASE_ANON_KEY=
  - REACT_APP_API_BASE_URL=http://localhost:8080
- npm install
- npm start

---

## 6) Quick Testing Checklist

- Sign up a user from the frontend (header sign-in).
- Create a program and verify it is persisted in Supabase `programs` table with `owner_id`.
- Import a CSV — rows should appear and be owned by the signed-in user.
- Trigger the notify workflow manually (GitHub Actions run or call /api/notify with x-notify-api-key) and check email.

---

## 7) Next Improvements (suggestions)

- Store per-program owner email and send owner-specific notifications.
- Add role-based features (admin view) using Supabase RLS + policies.
- Add file upload support (store CSV/attachments in Supabase Storage or S3).
- Add pagination for large program lists (server-side).

---

If you'd like, I can now:
- Produce a ready-to-paste `.env.example` for the server and `.env.local.example` for the frontend,
- Or generate the exact Railway/Render/Vercel step-by-step screenshots and common troubleshooting tips.