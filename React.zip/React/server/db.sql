-- SQL schema for 'programs' (Postgres). Run this in Supabase SQL editor or via psql.
CREATE TABLE IF NOT EXISTS programs (
  id text PRIMARY KEY,
  type text NOT NULL,
  description text,
  brand text,
  start_date date,
  end_date date,
  target numeric DEFAULT 0,
  target_percent numeric,
  achievement numeric DEFAULT 0,
  reward_amount numeric DEFAULT 0,
  reward_percent numeric DEFAULT 0,
  estimated_reward numeric DEFAULT 0,
  remaining_target numeric DEFAULT 0,
  progress_percent numeric DEFAULT 0,
  time_gone_percent numeric DEFAULT 0,
  status text DEFAULT 'Pending',
  payment_status text DEFAULT 'Unpaid',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- optional index for querying near-end programs
CREATE INDEX IF NOT EXISTS idx_programs_end_date ON programs (end_date);