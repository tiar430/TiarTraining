module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        emerald: '#2ecc71',
        sky: '#42a5f5',
      },
    },
  },
  plugins: [],
}